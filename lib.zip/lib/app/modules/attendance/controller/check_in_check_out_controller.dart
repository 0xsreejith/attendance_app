import 'package:get/get.dart';

class PunchInPunchOutController extends GetxController {
  var isPunchedIn = false.obs;
  var punchInTime = ''.obs;
  var punchLocation = ''.obs;

  void punchIn({required bool isOnsite}) {
    isPunchedIn.value = true;
    punchInTime.value = _getFormattedTime();
    punchLocation.value = isOnsite ? "On Site" : "Remote (Work From Home)";
  }

  void resetPunch() {
    isPunchedIn.value = false;
    punchInTime.value = '';
    punchLocation.value = '';
  }

  String _getFormattedTime() {
    final now = DateTime.now();
    return "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')} ${now.day}-${now.month}-${now.year}";
  }
}
