import 'package:flutter/material.dart';

class AppColor {
  static const Color lightGreen = Color(0xFFD8E9A8);
  static const Color darkGreen = Color(0xFF1E5128);
  static const Color primaryColor = Colors.blue;
}
