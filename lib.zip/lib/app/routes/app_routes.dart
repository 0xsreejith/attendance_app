abstract class Routes {
  static const HOME = '/home';
  static const MAIN = '/main';
  static const scanFace = "/scanFace";
  static const chekIn = '/checkIn';
}
